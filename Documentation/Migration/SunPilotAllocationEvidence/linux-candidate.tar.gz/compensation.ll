; ModuleID = '/home/runner/work/AstronomyKit/AstronomyKit/.context/issue83-allocation/linux-candidate/compensation.ll'
source_filename = "/home/runner/work/AstronomyKit/AstronomyKit/.context/issue83-allocation/linux-candidate/compensation.ll"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@__swift_reflection_version = linkonce_odr hidden constant i16 3
@_swift1_autolink_entries = private constant [77 x i8] c"-lswift_Concurrency\00-lswiftCore\00-lswift_StringProcessing\00-lswift_RegexParser\00", section ".swift1_autolink_entries", no_sanitize_address, align 8
@llvm.used = appending global [3 x ptr] [ptr @"$s12compensation14compensatedAddyySdz_SdzSdtF", ptr @__swift_reflection_version, ptr @_swift1_autolink_entries], section "llvm.metadata"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define protected swiftcc void @"$s12compensation14compensatedAddyySdz_SdzSdtF"(ptr nocapture dereferenceable(8) %0, ptr nocapture dereferenceable(8) %1, double %2) #0 {
entry:
  %3 = load double, ptr %0, align 8
  %4 = fadd double %3, %2
  %5 = tail call double @llvm.fabs.f64(double %3)
  %6 = tail call double @llvm.fabs.f64(double %2)
  %7 = fcmp ole double %6, %5
  %8 = fsub double %2, %4
  %9 = fadd double %3, %8
  %10 = fsub double %3, %4
  %11 = fadd double %10, %2
  %12 = select i1 %7, double %11, double %9
  %13 = load double, ptr %1, align 8
  %14 = fadd double %13, %12
  store double %14, ptr %1, align 8
  store double %4, ptr %0, align 8
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx16,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!swift.module.flags = !{!0}
!llvm.linker.options = !{}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"standard-library", i1 false}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 4, !"Objective-C Garbage Collection", i32 100796160}
!5 = !{i32 1, !"Swift Version", i32 7}
