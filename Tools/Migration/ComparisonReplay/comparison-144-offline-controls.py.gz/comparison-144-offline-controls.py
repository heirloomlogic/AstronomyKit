import base64
import copy
import importlib.util
import json
from pathlib import Path
from unittest import mock
root=Path.cwd();spec=importlib.util.spec_from_file_location('execution',root/'Scripts/migration/comparison_execution.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
proof=root/'.context/comparison-144-complete-historical'
checks=[]
def rejects(name,filename,mutate):
 raw=(proof/filename).read_bytes();saved=e.read_json(raw);changed=copy.deepcopy(saved);mutate(changed);reader=e.read_json
 with mock.patch.object(e,'read_json',side_effect=lambda data:changed if data==raw else reader(data)):
  try:e.verify_evidence(proof)
  except (ValueError,KeyError):checks.append({'name':name,'rejected':True});return
 raise AssertionError(name+' accepted')
rejects('saved-original-identity-success','assessment.json',lambda d:d.update(originalReproductionPassed=True))
rejects('saved-scientific-failure-cleared','assessment.json',lambda d:d.update(scientificComparisonPassed=False))
rejects('empty-mandatory-tools','candidate-build.json',lambda d:d.update(toolSHA256={}))
rejects('empty-source-population','candidate-build.json',lambda d:d.update(sourceInputsSHA256={}))
rejects('empty-generated-population','candidate-build.json',lambda d:d.update(generatedInputsSHA256={}))
rejects('stale-binary','candidate-build.json',lambda d:d.update(binarySHA256='0'*64))
rejects('false-manifest','candidate-build.json',lambda d:d.update(manifestSHA256='0'*64))
rejects('recipe-flags','candidate-build.json',lambda d:d['recipe'].update(extraSwiftFlags=['-Ounchecked']))
rejects('source-revision','attempt.json',lambda d:d.update(sourceRevision='0'*40))
rejects('missing-packet','raw-processes.json',lambda d:d['swiftCandidate'].pop())
rejects('extra-packet','raw-processes.json',lambda d:d['swiftCandidate'].append(d['swiftCandidate'][0]))
rejects('packet-order','raw-processes.json',lambda d:d['swiftCandidate'].reverse())
def model(d):
 packet=d['swiftCandidate'][0];packet['result']['model']='jpl-horizons';raw=json.dumps(packet['result']).encode();packet['stdoutBase64']=base64.b64encode(raw).decode();packet['stdoutSHA256']=e.sha(raw)
rejects('rehashed-model-change','raw-processes.json',model)
rejects('oracle-flags','oracle-build.json',lambda d:d.update(buildFlags=['-ffast-math']))
(root/'.context/comparison-144-offline-controls.json').write_text(json.dumps({'controlCount':len(checks),'controls':checks},indent=2,sort_keys=True)+'\n')
print(len(checks),'offline semantic rejection controls passed')
