import importlib.util,json,subprocess
from pathlib import Path
from unittest import mock
root=Path.cwd();before='75b5ca396804403a84b6b15704d3d6bd18b4415a';prior_path=root/'.context/fixer-146-attempt3-prior-validator.py';prior_path.write_bytes(subprocess.check_output(['git','show',before+':Scripts/migration/comparison_execution.py']))
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=root;m.PROTOCOL=root/'Documentation/Migration/comparison-replay-execution-protocol.json';return m
old=load(prior_path,'old_execution');new=load(root/'Scripts/migration/comparison_execution.py','new_execution');c=new.load(root/'Scripts/migration/run-comparison.py','active_nomination');read=Path.read_bytes;results=[]
for name in ['comparison-144-complete-historical','fixer-146-final-historical']:
 out=root/'.context'/name;attempt=new.read_json((out/'attempt.json').read_bytes());receipt=new.read_json((out/'candidate-build.json').read_bytes());log=(out/'swift-build.log').read_bytes();body=log.split(b'\n',1)[1] if log.startswith(new.ENVIRONMENT_MARKER) else log
 attempt['toolRevision']=before;attempt['toolSHA256']={p:new.sha(c.git_blob(before,p)) for p in new.TOOL_PATHS};attempt['protocolSHA256']=new.sha(c.git_blob(before,'Documentation/Migration/comparison-replay-execution-protocol.json'));receipt['toolSHA256']=attempt['toolSHA256'];capture=new.select_current_environment();log=new.ENVIRONMENT_MARKER+json.dumps(capture,sort_keys=True).encode()+b'\n'+body;receipt['command'][0]=capture['swiftCommand'][0];receipt['buildLogSHA256']=new.sha(log);rb=c.canonical_bytes(receipt);assessment=new.read_json((out/'assessment.json').read_bytes());assessment['candidateBuildSHA256']=new.sha(rb);replacements={out/'attempt.json':c.canonical_bytes(attempt),out/'candidate-build.json':rb,out/'swift-build.log':log,out/'assessment.json':c.canonical_bytes(assessment)}
 for label,e in [('before',old),('after',new)]:
  with mock.patch.object(Path,'read_bytes',lambda p:replacements.get(p,read(p))):
   try:e.verify_evidence(out);accepted=True;error=None
   except Exception as failure:accepted=False;error=str(failure)
  results.append({'population':name,'validator':label,'nominatedToolRevision':before,'actualOriginalBinarySHA256':receipt['binarySHA256'],'accepted':accepted,'error':error})
assert all(r['accepted']==(r['validator']=='before') for r in results)
(root/'.context/fixer-146-attempt3-active-nomination.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
