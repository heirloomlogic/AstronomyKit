import importlib.util,json,copy,base64
from pathlib import Path
from unittest import mock
root=Path.cwd();s=importlib.util.spec_from_file_location('execution',root/'Scripts/migration/comparison_execution.py');e=importlib.util.module_from_spec(s);s.loader.exec_module(e);c=e.load(root/'Scripts/migration/run-comparison.py','request_controls');read=Path.read_bytes;cases=e.read_json((c.ARTIFACT_PATH/'inputs.json').read_bytes())['cases'];component=full=0
for name in ['comparison-144-complete-current','fixer-146-final-current']:
 out=root/'.context'/name;raw=e.read_json((out/'raw-processes.json').read_bytes())
 for role in ['frozenC','swiftCandidate']:
  for index,case in enumerate(cases):
   for field in ['model','status']:
    changed=copy.deepcopy(raw);p=changed[role][index];result=p['result'];result[field]=('espenak-meeus' if case['command'][-1]=='jpl-horizons' else 'jpl-horizons') if field=='model' else ('bad-time' if result['status']=='success' else 'success');stdout=c.canonical_bytes(result);p['stdoutBase64']=base64.b64encode(stdout).decode();p['stdoutSHA256']=e.sha(stdout)
    try:e.validate_packet(p,case);raise AssertionError('mutated packet accepted')
    except ValueError:component+=1
    if index==0 and field=='model':
     rb=c.canonical_bytes(changed);assessment=e.read_json((out/'assessment.json').read_bytes());assessment['rawProcessesSHA256']=e.sha(rb);replacement={out/'raw-processes.json':rb,out/'assessment.json':c.canonical_bytes(assessment)}
     with mock.patch.object(Path,'read_bytes',lambda p:replacement.get(p,read(p))):
      try:e.verify_evidence(out);raise AssertionError('mutated full proof accepted')
      except ValueError:full+=1
assert component==144 and full==4
results={'classification':'unchanged-request-binding-regression-controls','packetModelStatusMutationsRejected':component,'actualFullVerifierWrongModelMutationsRejected':full,'caseCount':18,'generations':2,'runners':2,'protectedPacketsModified':False};(root/'.context/fixer-146-attempt3-request-controls.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
