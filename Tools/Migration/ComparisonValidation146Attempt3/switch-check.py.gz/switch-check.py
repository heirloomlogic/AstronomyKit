import importlib.util,json,copy
from pathlib import Path
from unittest import mock
root=Path.cwd();spec=importlib.util.spec_from_file_location('execution',root/'Scripts/migration/comparison_execution.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e);c=e.load(root/'Scripts/migration/run-comparison.py','switch_forgery');read=Path.read_bytes;results=[]
for source,target in [('comparison-144-complete-historical','fixer-146-final-historical'),('fixer-146-final-historical','comparison-144-complete-historical')]:
 out=root/'.context'/source;other=root/'.context'/target
 attempt=e.read_json((other/'attempt.json').read_bytes());receipt=e.read_json((out/'candidate-build.json').read_bytes());other_receipt=e.read_json((other/'candidate-build.json').read_bytes());log=(other/'swift-build.log').read_bytes()
 receipt['toolSHA256']=attempt['toolSHA256'];receipt['buildLogSHA256']=e.sha(log)
 for field in ('swift','platform'):receipt[field]=other_receipt[field]
 receipt['command'][0]=other_receipt['command'][0]
 rb=c.canonical_bytes(receipt);report=e.read_json((out/'assessment.json').read_bytes());report['candidateBuildSHA256']=e.sha(rb)
 replacements={out/'attempt.json':c.canonical_bytes(attempt),out/'candidate-build.json':rb,out/'swift-build.log':log,out/'assessment.json':c.canonical_bytes(report)}
 with mock.patch.object(Path,'read_bytes',lambda p:replacements.get(p,read(p))):
  try:
   verified=e.verify_evidence(out);accepted=True;error=None
  except Exception as failure:accepted=False;error=str(failure)
 results.append({'originalPopulation':source,'nominatedAuthorityPopulation':target,'actualOriginalBinarySHA256':e.sha((out/receipt['binaryRelativePath']).read_bytes()),'otherAuthorityBinarySHA256':other_receipt['binarySHA256'],'accepted':accepted,'error':error})
(root/'.context/fixer-146-attempt3-switch-check.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2));assert all(not r['accepted'] for r in results)
