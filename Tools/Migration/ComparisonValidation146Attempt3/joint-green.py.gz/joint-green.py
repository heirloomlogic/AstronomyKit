import base64,importlib.util,json
from pathlib import Path
from unittest import mock
root=Path.cwd();spec=importlib.util.spec_from_file_location('execution',root/'Scripts/migration/comparison_execution.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e);c=e.load(root/'Scripts/migration/run-comparison.py','joint_forgery');read=Path.read_bytes;results=[]
for label,directory in [('legacy','.context/comparison-144-complete-current'),('fresh','.context/fixer-146-final-current')]:
 out=root/directory;receipt=e.read_json((out/'candidate-build.json').read_bytes());original_log=(out/'swift-build.log').read_bytes();body=original_log.split(b'\n',1)[1] if original_log.startswith(e.ENVIRONMENT_MARKER) else original_log
 forged={'swiftCommand':['/nonexistent/forged/swift','--version'],'swiftExitCode':0,'swiftStdoutBase64':base64.b64encode((receipt['swift']+'\n').encode()).decode(),'swiftStderrBase64':'','platformCommand':['/nonexistent/forged/python','-c','import platform; print(platform.platform())'],'platformExitCode':0,'platformStdoutBase64':base64.b64encode(b'fabricated-platform\n').decode(),'platformStderrBase64':''}
 log=e.ENVIRONMENT_MARKER+json.dumps(forged,sort_keys=True).encode()+b'\n'+body
 receipt['platform']='fabricated-platform';receipt['command'][0]='/nonexistent/forged/swift';receipt['buildLogSHA256']=e.sha(log)
 receipt_bytes=c.canonical_bytes(receipt);assessment=e.read_json((out/'assessment.json').read_bytes());assessment['candidateBuildSHA256']=e.sha(receipt_bytes);replacements={out/'candidate-build.json':receipt_bytes,out/'swift-build.log':log,out/'assessment.json':c.canonical_bytes(assessment)}
 with mock.patch.object(Path,'read_bytes',lambda p:replacements.get(p,read(p))):
  try:
   report=e.verify_evidence(out);results.append({'population':label,'accepted':True,'failed':report['failed'],'scientificComparisonPassed':report['scientificComparisonPassed']})
  except Exception as error:results.append({'population':label,'accepted':False,'error':str(error)})
(root/'.context/fixer-146-attempt3-joint-green.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2));assert all(not r['accepted'] for r in results)
