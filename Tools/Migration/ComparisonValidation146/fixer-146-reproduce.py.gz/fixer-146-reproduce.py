import base64,copy,importlib.util,json
from pathlib import Path
from unittest import mock
root=Path.cwd();spec=importlib.util.spec_from_file_location('execution',root/'Scripts/migration/comparison_execution.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
out=root/'.context/comparison-144-complete-current';c=e.load(root/'Scripts/migration/run-comparison.py','reproducer_contract');original_read=Path.read_bytes
results=[]
for finding in ['comparison-rehashed-compiler-identity','comparison-rehashed-request-model-detachment']:
 receipt=e.read_json((out/'candidate-build.json').read_bytes());packets=e.read_json((out/'raw-processes.json').read_bytes());replacements={}
 if finding.endswith('compiler-identity'):
  receipt.update(swift='Invented Swift 999\nTarget: fictional-host',platform='UnrealOS-fabricated-platform')
  replacements[out/'candidate-build.json']=c.canonical_bytes(receipt)
 else:
  for role in packets:
   packet=next(p for p in packets[role] if p['id']=='mars-state-jpl');packet['result']['model']='espenak-meeus';raw=c.canonical_bytes(packet['result']);packet['stdoutBase64']=base64.b64encode(raw).decode();packet['stdoutSHA256']=e.sha(raw)
  replacements[out/'raw-processes.json']=c.canonical_bytes(packets)
 def read(path):return replacements.get(path,original_read(path))
 with mock.patch.object(Path,'read_bytes',read):
  cases=e.read_json((c.ARTIFACT_PATH/'inputs.json').read_bytes())['cases'];first=e.records(packets['frozenC'][:-1],cases);second=e.records(packets['swiftCandidate'][:-1],cases)
  attempt=e.read_json((out/'attempt.json').read_bytes());metadata=e.read_json((c.ARTIFACT_PATH/'metadata.json').read_bytes());protocol=e.read_json(e.PROTOCOL.read_bytes());report=e.assess(out,'current',attempt['sourceRevision'],c,cases,first,second,receipt,metadata,protocol);replacements[out/'assessment.json']=c.canonical_bytes(report)
  try:
   actual=e.verify_evidence(out);results.append({'id':finding,'acceptedBeforeFix':True,'failed':actual['failed'],'scientificComparisonPassed':actual['scientificComparisonPassed']})
  except Exception as error:results.append({'id':finding,'acceptedBeforeFix':False,'error':str(error)})
print(json.dumps(results,indent=2));(root/'.context/fixer-146-red-reproduction.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['acceptedBeforeFix'] for r in results)
